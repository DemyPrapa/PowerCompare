#!/usr/bin/env python3
"""
Συλλέκτης τιμολογίων.
Ροή: κατέβασμα σελίδων/PDF -> hash (άλλαξε κάτι;) -> εξαγωγή με AI (μόνο αν άλλαξε)
     -> επαλήθευση ότι τα στοιχεία υπάρχουν στο κείμενο -> συγχώνευση -> ιστορικό.
Τρέχει: python collector/collect.py
Απαιτεί: requests, beautifulsoup4, pdfplumber, anthropic (προαιρετικό, για εξαγωγή)
Μεταβλητή περιβάλλοντος: ANTHROPIC_API_KEY
"""
import hashlib, io, json, os, re, sys
from datetime import datetime, timezone
from pathlib import Path

import requests
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parent.parent
SOURCES = json.loads((ROOT / "collector/sources.json").read_text(encoding="utf-8"))
DATA_FILE = ROOT / "data/tariffs.json"
HIST_FILE = ROOT / "data/history.json"
STATE_FILE = ROOT / "data/state.json"   # hashes των σελίδων
HEADERS = {"User-Agent": "PowerCompareBot/1.0 (+contact: βάλε-email-σου)"}
NOW = datetime.now(timezone.utc).isoformat(timespec="seconds")


def load(path, default):
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else default


def fetch_text(url):
    """Επιστρέφει [(σελίδα, κείμενο)] για HTML ή PDF."""
    r = requests.get(url, headers=HEADERS, timeout=60)
    r.raise_for_status()
    if url.lower().endswith(".pdf") or "pdf" in r.headers.get("content-type", ""):
        import pdfplumber
        with pdfplumber.open(io.BytesIO(r.content)) as pdf:
            return [(i + 1, (p.extract_text() or "")) for i, p in enumerate(pdf.pages)]
    soup = BeautifulSoup(r.text, "html.parser")
    for t in soup(["script", "style", "nav", "footer"]):
        t.decompose()
    return [(1, re.sub(r"\s+", " ", soup.get_text(" ")).strip())]


def pdf_links(url):
    """Βρίσκει PDF (τιμοκατάλογοι/όροι) μέσα σε μια σελίδα."""
    try:
        r = requests.get(url, headers=HEADERS, timeout=60)
        soup = BeautifulSoup(r.text, "html.parser")
        out = []
        for a in soup.find_all("a", href=True):
            if a["href"].lower().split("?")[0].endswith(".pdf"):
                out.append(requests.compat.urljoin(url, a["href"]))
        return out
    except Exception:
        return []


PROMPT = """Είσαι αναλυτής τιμολογίων ρεύματος. Από το κείμενο εξήγαγε ΜΟΝΟ ό,τι αναγράφεται ρητά.
Επίστρεψε JSON: {"programs":[{"name","category"(fixed|variable|green|dynamic),"price_kwh"(αριθμός ή null),
"price_note","fixed_fee"(αριθμός ή null),"duration","conditions"(προϋποθέσεις εκπτώσεων),"exit_fee",
"fine_print":[{"title","text","quote"(ΑΚΡΙΒΕΣ απόσπασμα από το κείμενο),"page"}]}]}
Αν κάτι δεν αναγράφεται βάλε null. Μην μαντεύεις."""


def extract_with_ai(pages, url):
    key = os.getenv("ANTHROPIC_API_KEY")
    if not key:
        return None
    import anthropic
    client = anthropic.Anthropic(api_key=key)
    body = "\n".join(f"[Σελίδα {n}]\n{t}" for n, t in pages)[:150000]
    msg = client.messages.create(
        model=os.getenv("CLAUDE_MODEL", "claude-sonnet-5-5"),
        max_tokens=8000,
        messages=[{"role": "user", "content": f"{PROMPT}\n\nΠΗΓΗ: {url}\n\n{body}"}],
    )
    txt = msg.content[0].text
    m = re.search(r"\{.*\}", txt, re.S)
    return json.loads(m.group(0))["programs"] if m else None


def verify(prog, pages):
    """Επαληθεύει ότι τιμή και αποσπάσματα υπάρχουν πράγματι στο έγγραφο."""
    full = " ".join(t for _, t in pages)
    norm = lambda s: re.sub(r"\s+", " ", str(s)).lower()
    ok = True
    if prog.get("price_kwh") is not None:
        p = f"{prog['price_kwh']:.3f}".rstrip("0")
        ok &= (p in full) or (p.replace(".", ",") in full)
    for fp in prog.get("fine_print", []):
        q = norm(fp.get("quote", ""))
        ok &= bool(q) and q in norm(full)
    return bool(ok)


def slug(s):
    return re.sub(r"[^a-z0-9α-ω]+", "-", s.lower()).strip("-")


def main():
    data = load(DATA_FILE, {"providers": []})
    hist = load(HIST_FILE, [])
    state = load(STATE_FILE, {})
    by_id = {p["id"]: p for p in data["providers"]}
    changed_any = False

    for prov in SOURCES["providers"]:
        entry = by_id.setdefault(prov["id"], {"id": prov["id"], "name": prov["name"],
                                              "url": prov["pages"][0], "programs": []})
        seen, scanned_ok, extracted = set(), False, set()
        urls = list(prov["pages"])
        for u in list(urls):
            urls += pdf_links(u)
        for url in dict.fromkeys(urls):
            try:
                pages = fetch_text(url)
            except Exception as e:
                print(f"[!] {url}: {e}", file=sys.stderr)
                continue
            scanned_ok = True
            h = hashlib.sha256(json.dumps(pages, ensure_ascii=False).encode()).hexdigest()
            if state.get(url) == h:
                # δεν άλλαξε: απλώς επιβεβαιώνουμε ότι τα προγράμματα της πηγής ισχύουν
                for p in entry["programs"]:
                    if p.get("source_url") == url and p["status"] == "active":
                        p["last_confirmed"] = NOW; seen.add(p["id"])
                continue
            try:
                progs = extract_with_ai(pages, url)
            except Exception as e:
                print(f"[!] Αποτυχία εξαγωγής {url}: {e}", file=sys.stderr)
                continue
            if not progs:
                # Χωρίς API key ή κενό αποτέλεσμα: δεν αποθηκεύουμε το hash ώστε να ξαναδοκιμαστεί
                # και δεν αποσύρουμε τίποτα.
                print(f"[i] Άλλαξε το {url} αλλά δεν έγινε εξαγωγή (ANTHROPIC_API_KEY;).")
                continue
            state[url] = h
            extracted.add(url)
            for new in progs:
                pid = f"{prov['id']}-{slug(new['name'])}"
                new.update(id=pid, status="active", source_url=url,
                           last_confirmed=NOW, verified=verify(new, pages))
                seen.add(pid)
                old = next((p for p in entry["programs"] if p["id"] == pid), None)
                if old is None:
                    entry["programs"].append(new)
                    hist.append({"t": NOW, "provider": prov["id"], "program": pid, "event": "new"})
                else:
                    for k in ("price_kwh", "fixed_fee", "conditions", "exit_fee", "duration"):
                        if old.get(k) != new.get(k):
                            hist.append({"t": NOW, "provider": prov["id"], "program": pid,
                                         "event": "changed", "field": k, "old": old.get(k), "new": new.get(k)})
                    old.update(new)
                changed_any = True

        # Πρόγραμμα που δεν εμφανίζεται πια -> «αποσύρθηκε» (δεν σβήνεται, μένει στο ιστορικό).
        # Μόνο αν η σελίδα φορτώθηκε κανονικά, για να μη «αποσύρουμε» λόγω σφάλματος δικτύου.
        if scanned_ok:
            for p in entry["programs"]:
                if (p["status"] == "active" and p["id"] not in seen
                        and p.get("source_url") in extracted):
                    p["status"] = "withdrawn"
                    hist.append({"t": NOW, "provider": prov["id"], "program": p["id"], "event": "withdrawn"})
                    changed_any = True

    data["providers"] = list(by_id.values())
    data["updated_at"] = NOW
    data.pop("demo", None)
    DATA_FILE.parent.mkdir(exist_ok=True)
    DATA_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    HIST_FILE.write_text(json.dumps(hist, ensure_ascii=False, indent=2), encoding="utf-8")
    STATE_FILE.write_text(json.dumps(state, indent=2), encoding="utf-8")
    print("Ολοκληρώθηκε. Αλλαγές:", changed_any)


if __name__ == "__main__":
    main()
